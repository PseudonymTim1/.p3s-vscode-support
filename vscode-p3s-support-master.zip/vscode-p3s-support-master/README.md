# VsCode .p3s Support

Adds support for the Postal 3 scripting language (.p3s)

## Author

- Coleton Talley AKA Pseudonym_Tim - [Github](https://github.com/PseudonymTim1)
