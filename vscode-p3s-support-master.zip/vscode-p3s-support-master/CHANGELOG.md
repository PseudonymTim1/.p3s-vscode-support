# Changelog

## [0.1.0] - 2018-11-12
### Added
- Support for Postal 3 Scripts (.p3s) (Simple syntax highlighting, comment recognization)